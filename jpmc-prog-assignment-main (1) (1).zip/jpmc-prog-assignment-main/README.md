### Instructions To Run

```
g++ -std=c++17 -o simulation main.cpp Exchange.cpp OMS.cpp Trader.cpp FastTrader.cpp ProfitTracker.cpp
```

```
./simulation
```

```
python3 plot_results.py
```
